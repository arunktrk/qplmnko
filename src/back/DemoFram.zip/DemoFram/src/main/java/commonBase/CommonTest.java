package commonBase;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;

import static utility.AllureReportUtil.allureReportsDir;
import static utility.AllureReportUtil.allureResultsDir;

public class CommonTest {

    public static void cleanDirectory(String dirPath) {
        File dir = new File(dirPath);
        if (dir.exists()) {
            for (File file : dir.listFiles()) {
                if (!file.isDirectory()) {
                    file.delete();
                }
            }
            System.out.println("Cleaned directory: " + dirPath);
        } else {
            System.out.println("Directory not found: " + dirPath);
        }
    }

    public static void createDirectoryIfNotExist(String dirPath) {
        File dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
            System.out.println("Created directory: " + dirPath);
        }
    }

    public static void moveHistoryFolderToAllureResults() throws IOException {
        File allureReportsDirFile = new File(allureReportsDir);
        File allureResultsDirFile = new File(allureResultsDir);

        File historyDir = new File(allureReportsDirFile, "history");
        File folderDir = new File(allureReportsDirFile, "folder");

        // Check if 'history' directory exists and move it
        if (historyDir.exists() && historyDir.isDirectory()) {
            File destinationHistory = new File(allureResultsDirFile, "history");
            moveFolder(historyDir, destinationHistory);
        }

        // Check if 'folder' directory exists and move it
        if (folderDir.exists() && folderDir.isDirectory()) {
            File destinationFolder = new File(allureResultsDirFile, "folder");
            moveFolder(folderDir, destinationFolder);
        }
    }

    private static void moveFolder(File sourceFolder, File destinationFolder) throws IOException {
        if (sourceFolder.exists()) {
            // If the destination folder exists, replace it with the source folder
            if (destinationFolder.exists()) {
                // If the folder already exists, remove it and replace it with the new folder
                Files.walk(destinationFolder.toPath())
                        .sorted(Comparator.reverseOrder())
                        .map(Path::toFile)
                        .forEach(File::delete);  // Delete all contents of the existing folder
            } else {
                // If the folder doesn't exist, create it
                destinationFolder.mkdirs();
            }

            // Now move the source folder to the destination, replace the old one
            Path sourcePath = sourceFolder.toPath();
            Path destinationPath = destinationFolder.toPath();

            Files.move(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Moved folder: " + sourceFolder.getName() + " to " + destinationFolder.getAbsolutePath());
        }
    }


    public static void createScreenshotFolder(String folderName) {
        File folder = new File(folderName);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

}
