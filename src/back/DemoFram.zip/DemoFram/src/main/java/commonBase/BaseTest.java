package commonBase;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.annotations.Optional;
import utility.web.UiActions;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import static utility.AllureReportUtil.*;
import static utility.web.ScreenShotUtils.setBrowserName;

public class BaseTest {

    // --------------------- Instance Variables ---------------------
    protected static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    private static Properties configProperties = new Properties();
    public static Properties allureProperties = new Properties();
    public static String excelFilePath = "src/test/resources/config/UI_TestData.xlsx";
    public static String propertiesFilePath = "src/test/resources/config/" + "env" + "_config.properties";
    public static String browser;
    public static ThreadLocal<Map<String,String>> threadLocalTestData = ThreadLocal.withInitial(HashMap::new);

    // --------------------- Initialization ---------------------

    /**
     * Initialization method executed before the entire suite.
     *
     * @param env Test environment passed via @Parameters.
     */
    @BeforeSuite(alwaysRun = true)
    @Parameters({"env"})  // Reads the environment parameter passed in the TestNG XML
    public void beforeSuite(String env) {
        initializeConfig(env);  // Load environment-specific configuration
        cleanAllureResults();
        setupAllureEnvironment(env);
    }

    /**
     * Web driver setup performed before each test class.
     * Initializes the web driver if web execution is enabled.
     */
    @BeforeClass(alwaysRun = true)
    @Parameters({"webExecution", "browser"})  // Read the browser parameter from TestNG XML
    public void setup(String webExecution, @Optional String browser) {

        try {
            if (isWebExecutionEnabled(webExecution)) {
                initializeWebDriver(browser);  // Initialize WebDriver based on browser parameter
                setBrowserName(browser);
                logStep("Initializing for Web Test Execution.....");
                logStep(browser + " browser is selected for execution");

            } else {
                System.out.println("API Execution is Triggered and Web Execution is Skipped");
                logStep("Initializing for API Test Execution.....");
            }
        } catch (Exception e) {
            logStep("Failed to initialize Web Test Execution with browser: " + browser);
            throw e;
        }

    }

    /**
     * Load configuration properties for the tests based on environment.
     *
     * @param env The environment passed from the suite level.
     */
    private void initializeConfig(String env) {
        try {
            String envConfigFilePath = getEnvConfigFilePath(env);
            try (FileInputStream fis = new FileInputStream(envConfigFilePath)) {
                configProperties.load(fis);
                System.out.println("Properties loaded successfully from: " + envConfigFilePath);
            }

            System.out.println("Loaded properties for environment: " + env);
        } catch (IOException e) {
            System.err.println("Failed to load configuration file: " + propertiesFilePath);
            System.err.println(e.getMessage());
        }
    }

    /**
     * Return the config file path based on the environment (dynamic).
     *
     * @param env The environment name passed from the suite (e.g., UAT, SIT, etc.).
     * @return The correct path of the environment-specific config file.
     */
    private String getEnvConfigFilePath(String env) {
        return "src/test/resources/config/" + env + "_config.properties";
    }

    private void setupAllureEnvironment(String env) {

        // Safely retrieve system properties, fallback to "Unknown" if null
        String os = System.getProperty("os.name", "Unknown");
        String javaVersion = System.getProperty("java.version", "Unknown");
        String userName = System.getProperty("user.name", "Unknown");
        String testEnv = (env != null) ? env : "Unknown";
        browser = getProperty("browser");  // Retrieve the browser type (chrome/edge)

        // Handle potential null for browser
        browser = (browser != null) ? browser.toLowerCase() : "Unknown";

        // Set properties with null checks
        allureProperties.setProperty("OS", os);
        allureProperties.setProperty("Java Version", javaVersion);
        allureProperties.setProperty("User", userName);
        allureProperties.setProperty("Test Environment", testEnv);
        allureProperties.setProperty("Browser", browser);

        // Write to environment properties file
        try {
            File allureResultsDir = new File("allure-results");
            if (!allureResultsDir.exists()) allureResultsDir.mkdir();

            File envFile = new File("allure-results/environment.properties");
            try (FileOutputStream fos = new FileOutputStream(envFile)) {
                allureProperties.store(fos, "Environment Properties");
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    // --------------------- Web Driver Setup ---------------------


    /**
     * Check if web execution is enabled based on configuration.
     *
     * @return true if web execution is enabled, false otherwise.
     */
    @Parameters("webExecution")
    private boolean isWebExecutionEnabled(String webExecution) {
        return Boolean.parseBoolean(webExecution);
    }

    /**
     * Initialize WebDriver instance based on the configured browser.
     */
    private void initializeWebDriver(String browser) {
        if ("chrome".equalsIgnoreCase(browser)) {
            setupChromeDriver();
        } else if ("edge".equalsIgnoreCase(browser)) {
            setupEdgeDriver();
        } else {
            throw new IllegalArgumentException("Browser not supported: " + browser);
        }
    }

    /**
     * Setup the Chrome WebDriver with necessary options.
     */
    private void setupChromeDriver() {
        ChromeOptions options = new ChromeOptions();
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("profile.password_manager_enabled", false);
        prefs.put("credentials_enable_service", false);
        prefs.put("disk.cache.size", 0);
        options.setExperimentalOption("prefs", prefs);
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
//        options.addArguments("--headless");
        driver.set(new ChromeDriver(options));
        driver.get().manage().window().maximize();
    }

    /**
     * Setup the Edge WebDriver with necessary options.
     */
    private void setupEdgeDriver() {
        driver.set(new EdgeDriver());
        driver.get().manage().window().maximize();
    }


    /**
     * Get the WebDriver instance for the current thread.
     *
     * @return WebDriver instance.
     */
    public static WebDriver getDriver() {
        return driver.get();
    }

    // --------------------- Test Execution ---------------------

    /**
     * Retrieve properties from the config file.
     *
     * @param key The property key.
     * @return The value for the property.
     */
    public static String getProperty(String key) {
        return configProperties.getProperty(key);
    }

    /**
     * set test data in current Thread Map
     *
     * @param data The Test Data
     */
    public static void setTestData(Map<String, String> data) {
        Map<String, String> testData = threadLocalTestData.get();
        testData.clear();  // Clear any previous data
        testData.putAll(data);  // Add the new data
    }

    /**
     * get test data from Thread Map
     *
     * @return The value of test data
     */
    public static Map<String, String> getTestData() {
        return threadLocalTestData.get();  // Retrieve the test data for the current thread
    }

    // --------------------- Cleanup ---------------------

    /**
     * Remove the WebDriver instance for the current thread.
     */
    public static void removeDriver() {
        driver.remove();
    }


    /**
     * Cleanup after test class execution.
     */
    @AfterClass(alwaysRun = true)
    @Parameters({"webExecution"})
    public void tearDown(String webExecution) {
        try {
            if (isWebExecutionEnabled(webExecution) && getDriver() != null) {
                UiActions.waitForSeconds(5);
                if (getDriver() != null) {
                    logStep("Tearing down WebDriver for " + Thread.currentThread().getName());
                    getDriver().quit();
                }
            } else {
                logStep("API Execution is Completed");
            }
        } catch (Exception e) {
            logStep("Failed to properly shut down the WebDriver for " + Thread.currentThread().getName() + ": " + e);
            throw e;
        } finally {
            removeDriver();
        }
    }

    /**
     * After suite cleanup: Generate Allure report.
     */
    @AfterSuite(alwaysRun = true)
    @Parameters({"webExecution"})
    public void afterSuite(String webExecution) throws IOException, InterruptedException {
        generateAllureReport();
    }

    private static final Path responseFilePath = Paths.get("target/response.json");

//    @AfterMethod
//    public void afterScenario() {
//        // Clear the content or delete the response.json file after each scenario
//        try {
//            if (Files.exists(responseFilePath)) {
//                // To delete the file after each execution
//                Files.delete(responseFilePath);
//                System.out.println("response.json deleted successfully.");
//            }
//        } catch (IOException e) {
//            System.out.println("response.json");
//        }
//    }

}

