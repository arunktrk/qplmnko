package utility.web;

import commonBase.BaseTest;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class UiActions extends BaseTest {
    public static WebDriver driver = getDriver();
    public static WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));

    public synchronized static void highLight(WebElement element) {
        try {
            driver = getDriver();
            Actions Act = new Actions(driver);
            Act.moveToElement(element).build().perform();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].setAttribute('style','border:5px solid gold;');", element);
        } catch (Exception e) {
            System.out.println("Exception occurred => " + e.getMessage());
        }
    }

    public void enterValue(WebElement locator, String value) {
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        highLight(locator);
        element.sendKeys(value);
    }

    public void clearElement(WebElement locator) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        highLight(locator);
        element.clear();
    }

    public void clickElement(WebElement locator) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        highLight(locator);
        element.click();
    }

    public void Actions_clickElement(WebElement locator) {
        WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(locator));
        Actions actions = new Actions(driver);
        actions.moveToElement(clickableElement).click().build().perform();
        highLight(locator);
    }

    public void AssertPageTitle(String value) {
        Assert.assertEquals(getDriver().getTitle(), value);
    }

    public void AssertElement(WebElement locator) {
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        highLight(locator);
        element.isDisplayed();
    }

    public void getTest(WebElement locator, String value) {
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        value = element.getText();
        highLight(locator);
        System.out.println("Ref no = " + value);
    }

    public static void waitForSeconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void scrollToElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        highLight(element);
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void waitForElementToBeVisible(WebElement locator) {
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        highLight(locator);
        System.out.println("Element is visible now: " + element);

    }

    public void waitForElementToBeClickable(WebElement locator) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        highLight(locator);
        System.out.println("Element is visible now: " + element);

    }

    public void jsScrollToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }

    public void verifyExpectedValueAvailable(WebElement locator, String expectedValue) {

        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        String actualValue = element.getAttribute("value");
        highLight(locator);
        System.out.println(actualValue);

    }

    public void verifyExpectedTextAvailable(WebElement locator, String expectedTxt) {
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        highLight(locator);


    }

    public void handleConfirmationAlert() {
        if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
            Alert alert = driver.switchTo().alert();
            alert.accept();
        } else System.out.println("Alert is not present");
    }

    public String getElementText(WebElement locator) {
        String value = "";
        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        value = element.getText();
        highLight(locator);
        return value;
    }

    public void validateDropDownValues(WebElement locator, List<String> expectedValues) {

        WebElement element = wait.until(ExpectedConditions.visibilityOf(locator));
        Select select = new Select(locator);
        List<WebElement> options = select.getOptions();
        List<String> actualValues = new ArrayList<>();
        highLight(locator);
        for (int i = 1; i < options.size(); i++)
            actualValues.add(options.get(i).getText());
    }

    public void fluentWaitAndClick(final WebElement locator) {
        FluentWait<WebDriver> fluentWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(5))
                .ignoring(NoSuchElementException.class)
                .ignoring(ElementNotInteractableException.class);

        WebElement element = fluentWait.until(new Function<WebDriver, WebElement>() {
            public WebElement apply(WebDriver driver) {
                return locator;
            }
        });

        highLight(element);
        element.click();
    }
}