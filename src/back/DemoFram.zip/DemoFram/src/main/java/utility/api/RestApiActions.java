package utility.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

public class RestApiActions {

    public static Map<String, Object> responseMap;
    private static String filePath = "target/target/restResponse.json";

    public static Map<String, Object> parseJsonFileToMap(String filePath) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();

        return objectMapper.readValue(new File(filePath), Map.class);
    }

    public static String getValueFromResponse() {
        try {
            responseMap = parseJsonFileToMap(filePath);
            System.out.println("Response Map ="+ responseMap);

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
}


