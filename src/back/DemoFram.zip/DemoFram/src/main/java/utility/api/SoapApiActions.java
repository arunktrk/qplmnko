package utility.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import utility.AllureReportUtil;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static utility.AllureReportUtil.logStep;

public class SoapApiActions {

    public static Map<String, String> soapResponseMap;

    public static void getTagValueFromJson() {
        try {

            soapResponseMap = new HashMap<>();
            String jsonContent = new String(Files.readAllBytes(Paths.get("target/target/soapResponse.xml")));
             ObjectMapper mapper = new ObjectMapper();
             JsonNode rootNode = mapper.readTree(jsonContent);
             if (rootNode.isObject()) {
                 searchForResultKeys(rootNode, soapResponseMap);
             }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    private static void searchForResultKeys(JsonNode node, Map<String, String> soapData) {
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> field = fields.next();
                String key = field.getKey();
                JsonNode value = field.getValue();
                if (key.contains("Result")) {
                    soapData.put(key, value.asText());
                }
                searchForResultKeys(value, soapData);
            }
        } else if (node.isArray()) {
            for (JsonNode item : node) {
                searchForResultKeys(item, soapData);
            }
        }
    }


}