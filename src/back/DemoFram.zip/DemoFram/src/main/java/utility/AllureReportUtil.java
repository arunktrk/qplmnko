package utility;

import commonBase.BaseTest;
import io.qameta.allure.Allure;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.*;

import static commonBase.CommonTest.*;

public class AllureReportUtil extends BaseTest {

    public static String allureReportsDir = "allure-reports";    // Directory to save Allure reports
    public static String allureResultsDir = "allure-results";      // Directory for Allure results
     public static String  parentDirPath ="allure-results";

    // Method to clean existing Allure results and reports
    public static void cleanAllureResults() {
        cleanDirectory("allure-results");
        cleanDirectory("allure-reports");
        cleanDirectory("single-report");

    }


    // Method to log a step in Allure report
    public static void logStep(String description) {
        Allure.step(description);
    }



    // Helper method to recursively delete a directory and its contents


    public static void generateAllureReport() throws IOException, InterruptedException {
        String allureBinDir = "./allure-2.32.0/bin/allure.bat";  // Path to Allure binary
        String timestamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date());
        String reportFileName = "index_" + timestamp + ".html";  // Report file name with timestamp
        String archivedReportsDir = "archived-reports";  // Directory for archived reports
        String singleReportDir = "single-report";  // Directory for single HTML report

        // Create necessary directories if they don't exist
        createDirectoryIfNotExist(allureReportsDir);
        createDirectoryIfNotExist(singleReportDir);
        createDirectoryIfNotExist(archivedReportsDir);

        // Move necessary Karate JSON files to allure-results


        // Generate Allure report from allure-results
        List<String> generateCommand = new ArrayList<>();
        generateCommand.add(allureBinDir);
        generateCommand.add("generate");
        generateCommand.add(allureResultsDir);
        generateCommand.add("--output");
        generateCommand.add(allureReportsDir);
        generateCommand.add("--clean");
        generateCommand.add("--history");
        generateCommand.add("--trends");

        executeCommand(generateCommand);
        moveHistoryFolderToAllureResults();

        // Generate single HTML report (index.html)
        List<String> singleFileCommand = new ArrayList<>();
        singleFileCommand.add(allureBinDir);
        singleFileCommand.add("generate");
        singleFileCommand.add(allureResultsDir);
        singleFileCommand.add("--output");
        singleFileCommand.add(singleReportDir);
        singleFileCommand.add("--clean");
        singleFileCommand.add("--history");
        singleFileCommand.add("--trends");
        singleFileCommand.add("--single-file");  // Create a single HTML report

        executeCommand(singleFileCommand);

        // Check if the single HTML report is generated
        File generatedSingleReport = new File(singleReportDir + "/index.html");
        if (generatedSingleReport.exists()) {
            System.out.println("Single HTML Allure report generated successfully.");
        } else {
            System.out.println("Failed to generate single HTML report.");
            return;
        }

        // Copy the generated report to archive folder
        copyReportToArchive(singleReportDir, archivedReportsDir, reportFileName);
        System.out.println("Single HTML Allure report archived successfully.");
    }

    // Method to move Karate report files into allure-results folder




    private static void executeCommand(List<String> command) throws IOException, InterruptedException {
        ProcessBuilder processBuilder = new ProcessBuilder(command);
        processBuilder.inheritIO();
        Process process = processBuilder.start();

        // Capture error stream
        InputStream errorStream = process.getErrorStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println("ERROR: " + line);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            System.out.println("Failed to execute Allure command. Exit code: " + exitCode);
        }
    }

    // Method to copy the generated report to archived directory
    private static void copyReportToArchive(String singleReportDir, String archivedReportsDir, String reportFileName) {
        File originalFile = new File(singleReportDir + "/index.html");
        File copiedFile = new File(archivedReportsDir + "/" + reportFileName);

        if (originalFile.exists()) {
            try {
                Files.copy(originalFile.toPath(), copiedFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Report copied to: " + copiedFile.getAbsolutePath());
            } catch (IOException e) {
                System.out.println("Failed to copy the report to the archived folder.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Original report file not found.");
        }
    }



}


