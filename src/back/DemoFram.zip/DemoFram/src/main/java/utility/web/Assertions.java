package utility.web;

import io.qameta.allure.Step;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.asserts.SoftAssert;

import java.util.List;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * Utility class for performing hard and soft assertions with detailed Allure steps.
 */
public class Assertions extends UiActions {
    private static final SoftAssert softAssertion = new SoftAssert();

    // Hard Assertions

    /**
     * Verifies that two objects are equal.
     *
     * @param actual   the actual object.
     * @param expected the expected object.
     */


    @Step("Assert Equality: Actual = {actual}, Expected = {expected}")
    public static void assertEqual(Object actual, Object expected) {
            assertEquals(actual, expected);
    }

    @Step("Verify condition is true")
    public static void assertTrueCondition(boolean condition) {
        assertTrue(condition);
    }

    @Step("Verify element is displayed")
    public static void assertElementIsDisplayed(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
        highLight(element);
        assertTrue(element.isDisplayed());
    }

    @Step("Verify partial text in element")
    public static void assertPartialTextInElement(WebElement element, String expectedPartialText) {
        wait.until(ExpectedConditions.visibilityOf(element));
        highLight(element);
        assertTrue(element.getText().contains(expectedPartialText));
    }

    @Step("Verify text in element")
    public static void assertTextInElement(WebElement element, String expectedValue) {
        wait.until(ExpectedConditions.visibilityOf(element));
        highLight(element);
        assertEquals(element.getText(), expectedValue);
    }

    @Step("Verify text equality between two elements")
    public static void assertTextEqualElements(WebElement element1, WebElement element2) {
        wait.until(ExpectedConditions.visibilityOf(element1));
        highLight(element1);
        highLight(element2);
        assertEquals(element1.getText(), element2.getText());
    }

    @Step("Verify number of elements equals the expected value")
    public static void assertNumberOfElements(List<WebElement> elements, int expectedValue) {
        wait.until(ExpectedConditions.visibilityOf(elements.get(elements.size() - 1)));
        highLight((WebElement) elements);
        assertEquals(elements.size(), expectedValue);
    }

    @Step("Verify text equality between two strings")
    public static void assertTextToText(String actualText, String expectedText) {
        assertEquals(actualText, expectedText);
    }

    // Soft Assertions

    @Step("Verify condition is true (soft assertion)")
    public static void softAssertTrueCondition(boolean condition) {
        softAssertion.assertTrue(condition);
    }

    @Step("Verify element is displayed (soft assertion)")
    public static void softAssertElementIsDisplayed(WebElement element) {
        wait.until(ExpectedConditions.visibilityOf(element));
        highLight(element);
        softAssertion.assertTrue(element.isDisplayed());
    }

    @Step("Verify partial text in element (soft assertion)")
    public static void softAssertPartialTextInElement(WebElement element, String expectedPartialText) {
        wait.until(ExpectedConditions.visibilityOf(element));
        softAssertion.assertTrue(element.getText().contains(expectedPartialText));
    }

    @Step("Verify text in element (soft assertion)")
    public static void softAssertTextInElement(WebElement element, String expectedValue) {
        wait.until(ExpectedConditions.visibilityOf(element));
        highLight(element);
        softAssertion.assertEquals(element.getText(), expectedValue);
    }

    @Step("Verify text equality between two elements (soft assertion)")
    public static void softAssertTextEqualElements(WebElement element1, WebElement element2) {
        wait.until(ExpectedConditions.visibilityOf(element1));
        highLight(element1);
        highLight(element2);
        softAssertion.assertEquals(element1.getText(), element2.getText());
    }

    @Step("Verify number of elements equals the expected value (soft assertion)")
    public static void softAssertNumberOfElements(List<WebElement> elements, int expectedValue) {
        wait.until(ExpectedConditions.visibilityOf(elements.get(elements.size() - 1)));
        highLight((WebElement) elements);
        softAssertion.assertEquals(elements.size(), expectedValue);
    }
}