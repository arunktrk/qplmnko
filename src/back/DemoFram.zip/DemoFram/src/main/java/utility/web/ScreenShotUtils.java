//package utility.web;
//
//import commonBase.BaseTest;
//import io.qameta.allure.Allure;
//import io.qameta.allure.Step;
//import org.apache.commons.io.FileUtils;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//import org.testng.ITestResult;
//import org.testng.Reporter;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
//import static commonBase.CommonTest.createScreenshotFolder;
//
//public class ScreenShotUtils extends BaseTest {
//
//    public static WebDriver driver = BaseTest.getDriver();
//
//    private static final Logger LOGGER = Logger.getLogger(ScreenShotUtils.class.getName());
//    private static final String SCREENSHOT_FOLDER = "screenshots";
//
//    private static final String timestamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
//    private static File timestampFolder;
//    private static final Map<String, Integer> testCaseCounter = new HashMap<>();
//    private static final Map<String, File> testCaseFolderMap = new HashMap<>();
//
//    public ScreenShotUtils(WebDriver driver) {
//        this.driver = driver;
//        createScreenshotFolder(SCREENSHOT_FOLDER);
//        createTimestampFolder();
//    }
//
//    public static synchronized void createTimestampFolder() {
//        if (timestampFolder == null) {
//            timestampFolder = new File(SCREENSHOT_FOLDER + "/" + timestamp+File.separator);
//
//            if (!timestampFolder.exists()) {
//                timestampFolder.mkdirs();
//            }
//        }
//    }
//
//    public static synchronized File createTestCaseFolderWithSuffix(String testCaseName) {
//        createTimestampFolder();
//        Integer count = testCaseCounter.getOrDefault(testCaseName, 0);
//        String folderName = testCaseName;
//        File testCaseFolder = new File(timestampFolder + "/" + folderName);
//
//        if (testCaseFolder.exists()) {
//            count++;
//            while (true) {
//                String newFolderName = testCaseName + "_" + count;
//                testCaseFolder = new File(timestampFolder + "/" + newFolderName);
//                if (!testCaseFolder.exists()) {
//                    break;
//                }
//                count++;
//            }
//        } else if (!testCaseFolder.exists()) {
//            testCaseFolder.mkdirs();
//        }
//
//        testCaseCounter.put(testCaseName, count);
//        testCaseFolderMap.put(testCaseName, testCaseFolder);
//
//        return testCaseFolder;
//    }
//
//    @Step("Capturing screenshot for step: {stepDescription}")
//    public static void captureScreenShot(String stepDescription) {
//        try {
//            ITestResult result = Reporter.getCurrentTestResult();
//            String testCaseName = result.getMethod().getMethodName();
//            File testCaseFolder = testCaseFolderMap.get(testCaseName);
//            if (testCaseFolder == null) {
//                testCaseFolder = createTestCaseFolderWithSuffix(testCaseName);
//            }
//            File screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
//            String screenshotFileName = String.format("%s/%s.png", testCaseFolder, stepDescription);
//            File destinationFile = new File(screenshotFileName);
//            FileUtils.copyFile(screenshot, destinationFile);
//            try (FileInputStream screenshotStream = new FileInputStream(destinationFile)) {
//                Allure.addAttachment(stepDescription, "image/png", screenshotStream, "png");
//            }
//
//        } catch (IOException e) {
//            LOGGER.log(Level.SEVERE, "Failed to capture screenshot: " + e.getMessage(), e);
//        }
//    }
//}
package utility.web;

import commonBase.BaseTest;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import net.bytebuddy.asm.MemberSubstitution;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.Parameters;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import static commonBase.CommonTest.createScreenshotFolder;

public class ScreenShotUtils extends BaseTest {


    public static WebDriver driver = BaseTest.getDriver();
    public static ThreadLocal<String> browserName = new ThreadLocal<>();  // ThreadLocal for browser name

    private static final Logger LOGGER = Logger.getLogger(ScreenShotUtils.class.getName());
    private static final String SCREENSHOT_FOLDER = "screenshots";

    private static final String timestamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
    private static ThreadLocal<File> timestampFolder = new ThreadLocal<>();  // ThreadLocal for timestamp folder
    private static ThreadLocal<Map<String, Integer>> testCaseCounter = ThreadLocal.withInitial(HashMap::new);  // ThreadLocal for test case counter
    private static ThreadLocal<Map<String, File>> testCaseFolderMap = ThreadLocal.withInitial(HashMap::new);  // ThreadLocal for test case folder map


    public ScreenShotUtils(WebDriver driver) {
        this.driver = driver;
        createScreenshotFolder(SCREENSHOT_FOLDER);
        createTimestampFolder();
    }

    // Create timestamp folder for the current thread
    public static synchronized void createTimestampFolder() {
        if (timestampFolder.get() == null) {
            timestampFolder.set(new File(SCREENSHOT_FOLDER + "/" + timestamp + File.separator));

            if (!timestampFolder.get().exists()) {
                timestampFolder.get().mkdirs();
            }
        }
    }

    // Set browser name
    public static void setBrowserName(String browser) {
        browserName.set(browser != null ? browser.toLowerCase() : "test");
    }

    // Create test case folder with a suffix if the folder already exists
    public static synchronized File createTestCaseFolderWithSuffix(String testCaseName) {
        createTimestampFolder();

        String currentBrowserName = browserName.get();
        File browserFolder = new File(timestampFolder.get() + "/" + currentBrowserName);
        if (!browserFolder.exists()) {
            browserFolder.mkdirs();
        }

        Integer count = testCaseCounter.get().getOrDefault(testCaseName, 0);
        String folderName = testCaseName;
        File testCaseFolder = new File(browserFolder + "/" + folderName);

        if (testCaseFolder.exists()) {
            count++;
            while (true) {
                String newFolderName = testCaseName + "_" + count;
//                testCaseFolder = new File(timestampFolder+ "/" + newFolderName);
                testCaseFolder=new File(browserFolder +"/"+newFolderName);
//                testCaseFolder=new File(timestampFolder+ "/" +browserFolder +"/"+newFolderName);


                if (!testCaseFolder.exists()) {
                    break;
                }
                count++;
            }
        } else if (!testCaseFolder.exists()) {
            testCaseFolder.mkdirs();
        }

        testCaseCounter.get().put(testCaseName, count);
        testCaseFolderMap.get().put(testCaseName, testCaseFolder);

        return testCaseFolder;
    }

    // Capture screenshot with the provided step description
    @Step("Capturing screenshot for step: {stepDescription}")
    public static void captureScreenShot(String stepDescription) {
        try {
            ITestResult result = Reporter.getCurrentTestResult();
            String testCaseName = result.getMethod().getMethodName();
            File testCaseFolder = testCaseFolderMap.get().get(testCaseName);
            if (testCaseFolder == null) {
                testCaseFolder = createTestCaseFolderWithSuffix(testCaseName);
            }
            File screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
            String screenshotFileName = String.format("%s/%s.png", testCaseFolder, stepDescription);
            File destinationFile = new File(screenshotFileName);
            FileUtils.copyFile(screenshot, destinationFile);
            try (FileInputStream screenshotStream = new FileInputStream(destinationFile)) {
                Allure.addAttachment(stepDescription, "image/png", screenshotStream, "png");
            }

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to capture screenshot: " + e.getMessage(), e);
        }
    }
}