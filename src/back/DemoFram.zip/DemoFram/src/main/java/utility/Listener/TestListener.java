package utility.Listener;

import commonBase.BaseTest;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.*;
import org.testng.annotations.ITestAnnotation;
import utility.web.ScreenShotUtils;

import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static commonBase.BaseTest.excelFilePath;
import static commonBase.BaseTest.getProperty;
import static utility.AllureReportUtil.logStep;

@SuppressWarnings("unchecked")
public class TestListener implements ITestListener, IRetryAnalyzer, IAnnotationTransformer {


    int counter = 0;

    private Map<String, Boolean> testCaseExecutionType;
    int retryLimit = 1; //as per need

    @Override
    public void onStart(ITestContext context) {
        System.out.println("----------------------------------Starting test suite:------------------------------- " +
                "\n" + context.getName());

        logStep("-----------------------------Starting test suite:--------------------------------------- ");
    }

    @Override
    public void onFinish(ITestContext context) {
        System.out.println("------------------------------Finished test suite:------------------------------- " + "\n" + context.getName());
        logStep("-----------------------------Finished test suite:--------------------------------------- ");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("-------------------------------Test passed:------------------------------------ " + "\n" + result.getMethod().getMethodName());


    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("-----------------------------------Test failed:----------------------------------- " + "\n" + result.getMethod().getMethodName());
        System.out.println("Error: " + result.getThrowable().getMessage());
        logStep("-----------------------------Test failed:--------------------------------------- ");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("-----------------------------Test skipped:--------------------------------------- " + "\n" + result.getMethod().getMethodName());
        logStep("-----------------------------Test skipped:--------------------------------------- ");

    }

    @Override
    public void onTestStart(ITestResult result) {
        String testCaseName = result.getMethod().getMethodName();
        ScreenShotUtils.createTestCaseFolderWithSuffix(testCaseName);

        Object[] parameters = result.getParameters(); // Get data passed by DataProvider
        if (parameters != null && parameters.length > 0) {
            Map<String, String> tableData = (Map<String, String>) parameters[0];
            BaseTest.setTestData(tableData);
        }

        System.out.println(testCaseName+"=================================");
        logStep("-----------------------------Test Started:--------------------------------------- ");
    }

    public void transform(ITestAnnotation testannotation, Class testClass, Constructor testConstructor,
                          Method testMethod) {
        testannotation.setRetryAnalyzer(TestListener.class);
    }


    @Override
    public boolean retry(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE && counter < retryLimit) {
            Throwable throwable = result.getThrowable();
            if (!(throwable instanceof RuntimeException)) {
                System.out.println("----------------------------------Skipping retry : " + throwable.getMessage() + "------------------------------------");
                return false;
            }
            counter++;
            return true;
        }
        return false;
    }
}