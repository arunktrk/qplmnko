package utility.web;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import utility.Listener.SheetName;
import java.lang.reflect.Method;
import java.util.*;

public class ExcelReader {
    static String excelFilePath;
    public static ThreadLocal<Connection> threadLocalConnection = new ThreadLocal<>();
    public static ThreadLocal<Connection> threadLocalAPIConnection = new ThreadLocal<>();
    public static Fillo fillo;

    public static void setExcelFilePath(String sheet){
        switch (sheet){
            case "Login":
                excelFilePath = "\\src\\test\\resources\\config\\UAT_Login_TestData.xlsx";
                break;
            case "Home":
                excelFilePath = "\\src\\test\\resources\\config\\UAT_Home_TestData.xlsx";
                break;
            default:
                excelFilePath = "\\src\\test\\resources\\config\\UI_TestData.xlsx";
        }
    }

    public static Connection getFilloConnection() {
        try {
            Connection connection = threadLocalConnection.get();
            if (connection == null) {
                fillo = new Fillo();
                connection = fillo.getConnection(System.getProperty("user.dir") + excelFilePath);
                threadLocalConnection.set(connection);
            }
            return connection;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized static List<Map<String, String>> readFilloExcelData(String sheet, String testCaseId) {
        setExcelFilePath(sheet);
        Connection connection = getFilloConnection();
        List<Map<String, String>> allTestData = new ArrayList<>();
        try {
            String query = "Select * from " + sheet + " Where TestCaseName = '" + testCaseId + "'";
            Recordset recordset = connection.executeQuery(query);
            if (!recordset.next()) {
                // If no records found, log and skip the test
                System.out.println("No data found for TestCase: " + testCaseId + " in sheet: " + sheet);
                throw new SkipException("Skipping test: " + testCaseId + " as no data is found in the Excel sheet.");
            }
            do {
                Map<String, String> dataMap = new HashMap<>();
                List<String> fieldNames = recordset.getFieldNames();
                for (String fieldName : fieldNames) {
                    if (!fieldName.startsWith("COLUMN_") && !recordset.getField(fieldName).isEmpty()) {
                        dataMap.put(fieldName, recordset.getField(fieldName));
                    }
                }
                allTestData.add(dataMap);
            } while (recordset.next());
            connection.close();
        } catch (FilloException e) {
            throw new RuntimeException(e);
        }finally {
            threadLocalConnection.remove();
        }
        return allTestData;
    }

    @DataProvider(name="readFilloExcelData")
    public Object[][] getFilloExcelData(Method method) {
        String testCaseFilter=method.getName();
        Class<?> testClass = method.getDeclaringClass();
        SheetName sheetNameAnnotation = testClass.getAnnotation(SheetName.class);
        String sheetName=sheetNameAnnotation.value();
        List<Map<String, String>> allTestData = ExcelReader.readFilloExcelData(sheetName,testCaseFilter);
        System.out.println("Number of rows fetched for test case " + testCaseFilter + ": " + allTestData.size());
        Object[][] data = new Object[allTestData.size()][1];
        for (int i = 0; i < allTestData.size(); i++) {
            data[i][0] = allTestData.get(i);
        }
        return data;
    }

    public static Connection getAPIFilloConnection() {
        String apiExcelFilePath = "\\src\\test\\resources\\config\\API_TestData.xlsx";
        try {
            Connection connection = threadLocalAPIConnection.get();
            if (connection == null) {
                fillo = new Fillo();
                connection = fillo.getConnection(System.getProperty("user.dir") + apiExcelFilePath);
                threadLocalAPIConnection.set(connection);
            }
            return connection;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized static List<Map<String, String>> readAPIFilloExcelData(String sheet, String testCaseId) {
        Connection connection = getAPIFilloConnection();
        List<Map<String, String>> allTestData = new ArrayList<>();
        try {
            String query = "Select * from " + sheet + " Where TestCaseName = '" + testCaseId + "'";
            Recordset recordset = connection.executeQuery(query);
            if (!recordset.next()) {
                // If no records found, log and skip the test
                System.out.println("No data found for TestCase: " + testCaseId + " in sheet: " + sheet);
                throw new SkipException("Skipping test: " + testCaseId + " as no data is found in the Excel sheet.");
            }
            do {
                Map<String, String> dataMap = new HashMap<>();
                List<String> fieldNames = recordset.getFieldNames();
                for (String fieldName : fieldNames) {
                    if (!fieldName.startsWith("COLUMN_") && !recordset.getField(fieldName).isEmpty()) {
                        dataMap.put(fieldName, recordset.getField(fieldName));
                    }
                }
                allTestData.add(dataMap);
            } while (recordset.next());
        } catch (FilloException e) {
            throw new RuntimeException(e);
        } finally {
            if (connection != null) {
                connection.close();
            }
            threadLocalAPIConnection.remove();
        }
        return allTestData;
    }
}