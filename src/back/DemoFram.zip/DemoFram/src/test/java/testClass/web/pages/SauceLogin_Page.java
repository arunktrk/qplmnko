package testClass.web.pages;

import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utility.web.UiActions;

import static utility.AllureReportUtil.logStep;
import static utility.web.Assertions.assertElementIsDisplayed;
import static utility.web.ScreenShotUtils.captureScreenShot;


public class SauceLogin_Page extends UiActions {

    public WebDriver driver;
    String URL = getProperty("URL");

    @FindBy(id = "user-name")
    WebElement userNameField;
    @FindBy(id = "password")
    WebElement passwordField;
    @FindBy(id = "login-button")
    WebElement loginBTN;
    @FindBy(xpath = "//div[@class='bm-burger-button']//button")
    WebElement bmMenu;
    @FindBy(className = "product_label")
    WebElement productsLabel;
    @FindBy(id = "logout_sidebar_link")
    WebElement bmMenu_logout;
    @FindBy(className = "login_logo")
    WebElement swagLabsLogo_Loginpage;
    @FindBy(xpath = "//nav[@class='bm-item-list']//a")
    WebElement menuLists;

    public SauceLogin_Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    @Step("Launch the application URL")
    public void launchTheURL() {
        try {
            logStep("Launched the application URL: " + URL);
            driver.get(URL);
            assertElementIsDisplayed(userNameField);
            captureScreenShot("Login Page loaded");
        } catch (Exception e) {
            captureScreenShot("Failure - Login Page loaded");
            throw e;
        }
    }

    @Step("Entered the username and password for login")
    public void performLogin() {
        try {
            logStep("Enter User Name: " + getTestData().get("UserName") + " and Password: " + getTestData().get("Password"));
            enterValue(userNameField, getTestData().get("UserName"));
            enterValue(passwordField, getTestData().get("Password"));
            captureScreenShot("Login successful and landed on home page");
            clickElement(loginBTN);
            assertElementIsDisplayed(productsLabel);
            captureScreenShot("Login successful and landed on home page");
        } catch (Exception e) {
            captureScreenShot(" Failure - Perform Login action");
            throw e;
        }
    }

    @Step("Perform logout operation")
    public void performLogout() {
        try {
            fluentWaitAndClick(bmMenu);
            clickElement(bmMenu_logout);
            assertElementIsDisplayed(swagLabsLogo_Loginpage);
            captureScreenShot("Logout successful and landed on login page");
        } catch (Exception e) {
            captureScreenShot(" Failure - Logout action");
            throw e;
        }
    }
}