package testClass.api.support;

import java.text.DecimalFormat;

public class ApiCalculationHandler {

    public static String convertCelsiusToFahrenheit(String celsius) {
        double celsiusValue = Double.parseDouble(celsius); // Use double for more precision
        double fahrenheit = (celsiusValue * 9 / 5) + 32;
        if (fahrenheit == (int) fahrenheit) {
            return String.format("%d", (int) fahrenheit);
        } else {
            return String.format("%.1f", fahrenheit);
        }
    }

}