package testClass.web.tests;

import commonBase.BaseTest;
import io.qameta.allure.Severity;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testClass.web.support.WebFlows;
import utility.Listener.SheetName;
import utility.web.ExcelReader;

import java.util.Map;

import static io.qameta.allure.SeverityLevel.MINOR;
import static io.qameta.allure.SeverityLevel.NORMAL;

@SheetName("Home")
public class SauceHome_Test extends BaseTest {
    WebFlows Webflows;

    @BeforeMethod(alwaysRun = true)
    public void beforeEachMethod() {
        Webflows = new WebFlows(getDriver());
    }

    @Severity(MINOR)
    @Test(priority = 1,dataProvider = "readFilloExcelData",dataProviderClass = ExcelReader.class,groups = "Home")
    public void TC01_Home_VerifyMenuListOptions(Map<String,String> table){
        Webflows.performLoginToApplication();
        Webflows.performAssertionOnMenuList();
        Webflows.performLogoutOfApplication();
    }

    @Severity(NORMAL)
    @Test(priority = 2,dataProvider = "readFilloExcelData",dataProviderClass = ExcelReader.class,groups = "Home")
    public void TC02_Login_verifySoapApiResponseValue(Map<String,String> table){
        String tag = "@apiSoapTest2";
        Webflows.performLoginToApplication();
        Webflows.performInvokeApiAndRetrieveResponse_SOAP(tag);
        Webflows.performLogoutOfApplication();
    }

}
