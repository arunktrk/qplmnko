package testClass.web.support;

import testClass.web.pages.*;
import commonBase.BaseTest;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;

public class WebFlows extends BaseTest {

    SauceLogin_Page loginpage;
    SauceHome_Page homePage;

    public WebFlows(WebDriver driver) {
        loginpage = new SauceLogin_Page(driver);
        homePage = new SauceHome_Page(driver);
    }

    @Step("Perform login using valid credentials")
    public void performLoginToApplication() {
        loginpage.launchTheURL();
        loginpage.performLogin();
    }

    @Step("Perform logout")
    public void performLogoutOfApplication() {
            loginpage.performLogout();
    }



    @Step("Login and get The Data from SOAP Api response")
    public void performInvokeApiAndRetrieveResponse_SOAP(String tag) {
            homePage.getTheDataFromSOAPApiResponse(tag);
    }

    @Step("Perform assertion on menu list items")
    public void performAssertionOnMenuList() {
            homePage.assertMenulistOptions();
    }

    @Step("Login and get The Data from REST Api response")
    public void performInvokeApiAndRetrieveResponse_REST(String apiTag) {
        homePage.executeAndExtractDataRESTApi(apiTag);
    }


}