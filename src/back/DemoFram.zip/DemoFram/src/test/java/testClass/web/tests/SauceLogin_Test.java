package testClass.web.tests;

import commonBase.BaseTest;
import io.qameta.allure.Severity;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testClass.web.support.WebFlows;
import utility.Listener.SheetName;
import utility.web.ExcelReader;
import java.util.Map;
import static io.qameta.allure.SeverityLevel.*;

@SheetName("Login")
public class SauceLogin_Test extends BaseTest {
    WebFlows Webflows;

    @BeforeMethod(alwaysRun = true)
    public void beforeEachMethod() {
        Webflows = new WebFlows(getDriver());
    }

    @Severity(BLOCKER)
    @Test(priority = 1,dataProvider = "readFilloExcelData",dataProviderClass = ExcelReader.class,groups = "Login")
    public void TC01_Login_verifyLoginWithMultipleDatasets(Map<String,String> table){
        Webflows.performLoginToApplication();
        Webflows.performLogoutOfApplication();
    }

    @Severity(CRITICAL)
    @Test(priority = 2,dataProvider = "readFilloExcelData",dataProviderClass = ExcelReader.class,groups = "Login")
    public void TC02_Login_verifyRestApiResponseValue(Map<String,String> table){
        String tag = "@apiRestTest2";
        Webflows.performLoginToApplication();
        Webflows.performInvokeApiAndRetrieveResponse_REST(tag);
        Webflows.performLogoutOfApplication();
    }

    @Severity(NORMAL)
    @Test(priority = 2,dataProvider = "readFilloExcelData",dataProviderClass = ExcelReader.class,groups = "Login")
    public void TC03_Login_verifySoapApiResponseValue(Map<String,String> table){
        String tag = "@apiSoapTest2";
        Webflows.performLoginToApplication();
        Webflows.performInvokeApiAndRetrieveResponse_SOAP(tag);
        Webflows.performLogoutOfApplication();
    }


}
