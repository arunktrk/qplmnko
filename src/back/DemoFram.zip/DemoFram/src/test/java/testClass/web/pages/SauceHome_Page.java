package testClass.web.pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testClass.api.support.ApiSupportTest;
import utility.AllureReportUtil;
import utility.api.RestApiActions;
import utility.api.SoapApiActions;
import utility.web.Assertions;
import utility.web.UiActions;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;
import static utility.api.RestApiActions.getValueFromResponse;
import static utility.api.RestApiActions.responseMap;
import static utility.api.SoapApiActions.*;
import static utility.web.ScreenShotUtils.captureScreenShot;

public class SauceHome_Page extends UiActions {

    public WebDriver driver;

    @FindBy(xpath = "//div[@class='bm-burger-button']//button")
    WebElement bmMenu;
    @FindBy(xpath = "//button[text()='Close Menu']")
    WebElement btnClose;

    @FindBy(xpath = "//nav[@class='bm-item-list']")
    WebElement itemsMenu;

    public SauceHome_Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @Step("Assert all menu list options")
    public void assertMenulistOptions() {
        try {
            // Click on the burger menu
            fluentWaitAndClick(bmMenu);
            waitForElementToBeVisible(itemsMenu);
            // Retrieve the list of menu items
            // Wait for the menu to appear (optional)
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//nav[@class='bm-item-list']")));
            // Retrieve the list of menu items
            List<WebElement> burgerMenuLists = driver.findElements(By.xpath("//nav[@class='bm-item-list']//a"));
            List<String> actualMenuItems = new ArrayList<>();
            for (WebElement menuItem : burgerMenuLists) {
                actualMenuItems.add(menuItem.getText());
                System.out.println(actualMenuItems + "---------");
            }

            // Define the expected menu items
            List<String> expectedMenuItems = List.of("All Items", "About", "Logout", "Reset App State");

            // Assert that the actual menu items match the expected menu items
            assertEquals(actualMenuItems, expectedMenuItems, "Menu items do not match!");

            // Capture screenshot on success
            captureScreenShot("Menu list options verified successfully");
        } catch (Exception e) {
            // Capture screenshot on failure
            captureScreenShot("Failure - Menu list options verification");
            throw e;
        }
       clickElement(btnClose);
    }

    @Step("Get Soap API Response")
    public void getTheDataFromSOAPApiResponse(String apiTag) {
        ApiSupportTest.apiSupport(apiTag);
        getTagValueFromJson();
        System.out.println("Celsius to Farenheit Result ="+soapResponseMap.get("CelsiusToFahrenheitResult"));
    }


    @Step("Get The Data From API Response")
    public void executeAndExtractDataRESTApi(String apiTag) {
        ApiSupportTest.apiSupport(apiTag);
        getValueFromResponse();
        System.out.println("id ="+responseMap.get("id"));
        System.out.println("userId ="+responseMap.get("userId"));

    }


}
