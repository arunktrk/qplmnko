package testClass.api.support;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import io.qameta.allure.Step;
import org.apache.commons.lang.StringUtils;
import org.testng.annotations.Parameters;
import utility.AllureReportUtil;
import java.util.Map;

public class ApiSupportTest extends AllureReportUtil {


    @Parameters({"karate.env","karate.tags"})
    public static void apiSupport(String strTagName)  {
        String featurePath = "src/test/java/TestClass/api/test";
        Results results = Runner.path(featurePath)
                .outputCucumberJson(true)
                .systemProperty("karate.config", "classpath:karate-config.js")
                .tags(strTagName)
                .parallel(1);
        System.out.println(results.getReportDir() + "------------------------------------------------------------------");
    }

    @Step("Log URL")
    public static void logUrl(String url) {
        if (StringUtils.isNotEmpty(url)) {
           AllureReportUtil.logStep("Request URL,text/plain"  + url);
        } else {
            AllureReportUtil.logStep("No URL Provided " + url );
        }
    }

    @Step("Log REST Response Payload")
    public static void logResponse(Map<String, Object> responsePayload) {
        if (responsePayload != null && !responsePayload.isEmpty()) {
            String jsonResponsePayload = StringUtils.defaultString(responsePayload.toString(), "No Response Payload");
            AllureReportUtil.logStep("Response Payload = "+ jsonResponsePayload);
        } else {
            AllureReportUtil.logStep("No Response Payload");
        }
    }

    @Step("Log REST Response Headers")
    public static void logResponseHeaders(Map<String, Object> responseHeaders) {
        if (responseHeaders != null && !responseHeaders.isEmpty()) {
            String headers = responseHeaders.toString();
            AllureReportUtil.logStep("Response Headers = "+ headers);
        } else {
            AllureReportUtil.logStep("Response Headers is Empty");
        }
    }

    @Step("Log Status Code")
    public static void logStatusCode(Integer statusCode) {
        if (statusCode != null) {
            AllureReportUtil.logStep("Status Code = "+ String.valueOf(statusCode));
        } else {

            AllureReportUtil.logStep("There is No status Code");
        }
    }

    @Step("Log Assert values")
    public static void assertEqual(Object actual, Object expected, String assertionMessage) {
        boolean assertionResult = actual != null && actual.equals(expected);

        if (assertionResult) {
            AllureReportUtil.logStep("Assertion Passed - "+  assertionMessage );
        } else {
            AllureReportUtil.logStep("Assertion Failed - " + assertionMessage );
        }
        if (!assertionResult) {
            throw new AssertionError(assertionMessage + ": Expected [" + expected + "] but got [" + actual + "]");
        }
    }

    @Step("Log Method Name")
    public static void logMethodName(String method) {
        System.out.println("HTTP Method - " + method);
        AllureReportUtil.logStep("HTTP Method =" + method);
    }

    @Step("Log SOAP Request Payload")
    public static void logSoapRequest(String requestPayload) {
        if (requestPayload != null && !requestPayload.isEmpty()) {
            AllureReportUtil.logStep("SOAP Request Payload = " + requestPayload);
        } else {
            AllureReportUtil.logStep("No SOAP Request Payload");
        }
    }
    @Step("Log SOAP Response Payload")
    public static void logSoapResponse(String responsePayload) {
        if (responsePayload != null && !responsePayload.isEmpty()) {
            AllureReportUtil.logStep("SOAP Response Payload = " + responsePayload);
        } else {
            AllureReportUtil.logStep("No SOAP Response Payload");
        }
    }
}