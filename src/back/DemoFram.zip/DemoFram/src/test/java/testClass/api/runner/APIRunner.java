package testClass.api.runner;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import commonBase.BaseTest;
import io.qameta.allure.karate.AllureKarate;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class APIRunner extends BaseTest {

    public static String featurePath = "src/test/java/testClass/api/test";

    @Parameters({"strTagName"})
    @BeforeTest
    public static void triggerSpecificAPIScenario(String strTagName) {
        Results results = Runner.path(featurePath)
                .tags(strTagName)
                .hook(new AllureKarate())
                .parallel(0);
    }
}
