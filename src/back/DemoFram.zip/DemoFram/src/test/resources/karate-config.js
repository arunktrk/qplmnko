function() {
  var env = karate.env; // Access 'karate.env' system property
  karate.log('karate.env system property is:', env); // Log the value of 'karate.env'

  if (!env) {
    // Default to 'dev' environment if 'karate.env' is not set
    env = 'dev';
  }

  var config = {};  // Initialize config object

  // You can log or set any environment-specific configurations here
  if (env == 'dev') {
    karate.log('Environment is set to dev');
  } else if (env == 'prod') {
    karate.log('Environment is set to prod');

  } else {
    karate.log('Unknown environment:', env);
  }

  // Log any relevant environment-related information, if needed
  karate.log('Using environment:', env);

  // Common configurations for SSL and timeouts
  karate.configure("ssl", true);  // Enable SSL
  karate.configure('logPrettyRequest', true);  // Pretty request logging
  karate.configure('logPrettyResponse', true);  // Pretty response logging
  karate.configure('connectTimeout', 90000);  // Connection timeout
  karate.configure('readTimeout', 90000);  // Read timeout

  // Helper function to extract data from API response
  function extractData(response, fields) {
    var extracted = {};
    fields.forEach(function(field) {
      extracted[field] = response[field];
    });
    return extracted;
  }

  // Higher-order function to extract specific fields from response
  function karateExtract(...fields) {
    return function(response) {
      return extractData(response, fields);
    };
  }

  // Function to capture and log API request, response, and headers
  // Will be used in Karate feature files
  function logApiResponse(requestPayload, jsonResponse, responseHeaders) {
    karate.call("classpath:log-api-response.feature", {
      requestPayload: requestPayload,
      jsonResponse: jsonResponse,
      responseHeaders: responseHeaders
    });
  }
//  karate.configure('report', { dir: 'allure-results' });

karate.configure('report', { showLog: true, showAllure: true });


  // Expose the functions to Karate's feature files by adding them to the config object
  config.extractData = extractData;
  config.karateExtract = karateExtract;
  config.logApiResponse = logApiResponse; // Expose this to the Karate feature files

  // Return the final config object
  return config;
}
